\set ON_ERROR_STOP on
\ir migrations/0001_init.sql
\ir migrations/0002_security_and_rls.sql
\ir migrations/0003_indexes.sql
\ir migrations/0004_storage.sql
\ir migrations/0005_soft_delete.sql
\ir migrations/0006_auditing.sql
\ir migrations/0007_views_and_functions.sql
\ir migrations/0008_rpc.sql
\ir seed/000_seed.sql
\ir seed/001_enhanced_seed.sql


