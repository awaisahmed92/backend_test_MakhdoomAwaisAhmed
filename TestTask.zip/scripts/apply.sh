#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "DATABASE_URL is required. Example: postgres://postgres:<password>@<host>:5432/postgres?sslmode=require"
  exit 1
fi

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$(dirname "$0")/../apply_all.sql"

echo "All migrations and seed applied successfully."


