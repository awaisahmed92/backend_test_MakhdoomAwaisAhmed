#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT_DIR/docs/ERD.mmd"
OUT_PNG="$ROOT_DIR/docs/ERD.png"

if [[ ! -f "$SRC" ]]; then
  echo "ERD source not found: $SRC"
  exit 1
fi

if command -v docker >/dev/null 2>&1; then
  docker run --rm -u "$(id -u):$(id -g)" -v "$ROOT_DIR:/work" minlag/mermaid-cli:latest -i docs/ERD.mmd -o docs/ERD.png
  echo "Rendered ERD to $OUT_PNG via Docker mermaid-cli"
  exit 0
fi

if command -v npx >/dev/null 2>&1; then
  npx -y @mermaid-js/mermaid-cli -i "$SRC" -o "$OUT_PNG"
  echo "Rendered ERD to $OUT_PNG via npx @mermaid-js/mermaid-cli"
  exit 0
fi

echo "Neither docker nor npx found. Install Docker Desktop or Node.js (npx)."
exit 1


