## Pitch Outline: AI-Powered Recruitment SaaS (Backend & Security)

### 1. Problem & Goal
- Too many CVs per job; manual screening is slow.
- Goal: AI ranks candidates per job; recruiters review summaries and download CVs.

### 2. Architecture Overview
- Supabase (Postgres + Auth + Storage).
- Multi-tenant via `organizations` and `organization_members` with roles.
- AI pipeline writes `matches` and `ai_summaries`.

### 3. Data Model (ERD)
- See `docs/ERD.mmd`.
- Key tables: `jobs`, `candidates`, `matches`, `ai_summaries`.

### 4. Security & Compliance
- Row Level Security everywhere; helper functions enforce tenancy.
- Soft-deletes via `deleted_at` and triggers.
- Auditing: `audit.events` logs inserts/updates/deletes.

### 5. Developer Experience
- Database-as-Code: migrations in `/migrations`, seed in `/seed`.
- One-command apply: `bash scripts/apply.sh`.
- RPCs for frontend/backend: `api_get_job_results`, `api_queue_processing_run`.

### 6. Demo Flow
1) Create job → upload CVs (to Storage) → queue processing run.
2) AI worker upserts scores and summaries.
3) Frontend calls `api_get_job_results` to render ranked table.

### 7. Next Steps
- Add analytics, feedback loop, and export webhooks.
- Enterprise: SSO, SCIM, detailed audit exports.


