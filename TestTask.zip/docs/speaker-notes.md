## 5-Minute Loom Speaker Notes (Verbatim)

Hi, this is my backend and security architecture for an AI-powered recruitment SaaS on Supabase.

Goal: Recruiters upload CVs, add a job description, the system uses AI to score candidates per job, and the team reviews a ranked list with AI summaries and can download the full CV.

Tenancy and roles: We model SaaS tenants as `organizations` and membership in `organization_members` with roles `owner`, `admin`, `recruiter`, and `viewer`. Every domain row carries an `organization_id` for isolation.

Core data model: `jobs` and `candidates` are scoped to an organization. `candidate_documents` stores the path to files in Supabase Storage. The AI pipeline writes `matches` with a 0–100 score per candidate-job pair, and `ai_summaries` with the model-generated recommendation and payload for traceability. Recruiters can add `notes`.

Security and RLS: Row Level Security is enabled on all tables. Two helpers enforce tenancy and least privilege: `is_org_member(org_id)` and `has_org_role(org_id, roles)`. Members can only see and modify data for their organizations. Owners/Admins manage membership, invites, webhooks, and API keys.

Storage: A `candidate-cvs` bucket holds resumes. Storage policies restrict reads to org members of the candidate’s org and restrict uploads to recruiters and above.

Soft-deletes and auditing: Deletions set `deleted_at`; RLS filters out soft-deleted rows. All inserts, updates, and deletes are logged to `audit.events` with actor, table, operation, and before/after snapshots for compliance.

Developer experience: This is Database-as-Code. Migrations live in `/migrations`, seeds in `/seed`. You can apply everything with one command: `bash scripts/apply.sh`. There’s a view `v_ranked_matches` and function `get_job_results(org_id, job_id)` to power the results table. RPCs include `api_get_job_results(job_id)` and `api_queue_processing_run(org_id, job_id)`.

Quick demo: After applying migrations and seeds, I can run `select * from public.get_job_results('<org_id>', '<job_id>') order by score desc;` to show ranked candidates and summaries. I can also view `select * from audit.events order by occurred_at desc limit 10;` to show the audit trail. For the CVs, the Storage policies ensure only teammates from the same org can access them.

Why this works for SaaS: Tenancy is enforced in SQL through RLS, not just in app code. Roles provide least-privilege access. Soft-deletes and audit logs support compliance. Indexes keep org/job/candidate queries fast. This is production-ready to integrate with an AI worker and a React frontend.

Next steps: add SSO/SCIM for enterprise, analytics and feedback loops for model quality, and export webhooks.

Thanks for watching.


