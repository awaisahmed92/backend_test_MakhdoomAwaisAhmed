-- Migration: Views and helper functions for presentation

-- View: ranked matches with candidate + job context
create or replace view public.v_ranked_matches as
select
  m.organization_id,
  m.job_id,
  j.title as job_title,
  m.candidate_id,
  c.full_name as candidate_name,
  c.email as candidate_email,
  m.score,
  coalesce(a.summary, '') as ai_summary,
  m.created_at
from public.matches m
join public.jobs j on j.id = m.job_id and j.deleted_at is null
join public.candidates c on c.id = m.candidate_id and c.deleted_at is null
left join public.ai_summaries a on a.job_id = m.job_id and a.candidate_id = m.candidate_id and a.deleted_at is null
where m.deleted_at is null;

-- Secure the view via underlying table RLS; no explicit policies needed.

-- Function: get_job_results(org_id, job_id) returns ranked results
create or replace function public.get_job_results(p_org_id uuid, p_job_id uuid)
returns table (
  candidate_id uuid,
  candidate_name text,
  candidate_email text,
  score numeric,
  ai_summary text
) language sql stable as $$
  select
    candidate_id,
    candidate_name,
    candidate_email,
    score,
    ai_summary
  from public.v_ranked_matches
  where organization_id = p_org_id
    and job_id = p_job_id
  order by score desc, candidate_name asc;
$$;

-- Function: upsert_match_and_summary (used by AI pipeline)
create or replace function public.upsert_match_and_summary(
  p_org_id uuid,
  p_job_id uuid,
  p_candidate_id uuid,
  p_score numeric,
  p_summary text,
  p_payload jsonb default null
) returns void language plpgsql security definer as $$
begin
  -- upsert match
  insert into public.matches (organization_id, job_id, candidate_id, score, created_by)
  values (p_org_id, p_job_id, p_candidate_id, p_score, auth.uid())
  on conflict (job_id, candidate_id) do update set score = excluded.score, created_by = auth.uid(), created_at = now(), deleted_at = null;

  -- upsert ai_summaries
  insert into public.ai_summaries (organization_id, job_id, candidate_id, summary, json_payload, created_by)
  values (p_org_id, p_job_id, p_candidate_id, p_summary, p_payload, auth.uid())
  on conflict (job_id, candidate_id) do update set summary = excluded.summary, json_payload = excluded.json_payload, created_by = auth.uid(), created_at = now(), deleted_at = null;
end;
$$;


