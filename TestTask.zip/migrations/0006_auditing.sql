-- Migration: Auditing for CRUD events

create schema if not exists audit;

create table if not exists audit.events (
  id bigserial primary key,
  occurred_at timestamptz not null default now(),
  actor_user_id uuid,
  actor_role text,
  table_name text not null,
  operation text not null, -- insert | update | delete | soft_delete
  organization_id uuid,
  row_id uuid,
  before_data jsonb,
  after_data jsonb
);

comment on table audit.events is 'Immutable log of data changes for compliance and debugging';

create or replace function audit.log_event()
returns trigger language plpgsql security definer as $$
declare
  org_id uuid;
  row_uuid uuid;
  before_row jsonb;
  after_row jsonb;
  op text;
begin
  op := TG_OP::text;

  if TG_OP = 'INSERT' then
    after_row := to_jsonb(NEW);
    if NEW ? 'organization_id' then
      org_id := NEW.organization_id;
    end if;
    if NEW ? 'id' then
      row_uuid := NEW.id;
    end if;
  elsif TG_OP = 'UPDATE' then
    before_row := to_jsonb(OLD);
    after_row := to_jsonb(NEW);
    if NEW ? 'organization_id' then
      org_id := NEW.organization_id;
    elsif OLD ? 'organization_id' then
      org_id := OLD.organization_id;
    end if;
    if NEW ? 'id' then
      row_uuid := NEW.id;
    else
      row_uuid := OLD.id;
    end if;
  elsif TG_OP = 'DELETE' then
    before_row := to_jsonb(OLD);
    if OLD ? 'organization_id' then
      org_id := OLD.organization_id;
    end if;
    if OLD ? 'id' then
      row_uuid := OLD.id;
    end if;
  end if;

  insert into audit.events (actor_user_id, actor_role, table_name, operation, organization_id, row_id, before_data, after_data)
  values (auth.uid(), current_setting('request.jwt.claim.role', true), TG_TABLE_NAME, op, org_id, row_uuid, before_row, after_row);

  if TG_OP = 'DELETE' then
    return OLD;
  else
    return NEW;
  end if;
end;
$$;

-- Attach to key tables (exclude highly volatile tables if desired)
do $$
begin
  perform 1;
  for SELECT table_name from information_schema.tables where table_schema='public' and table_name in (
    'organizations','organization_members','profiles','jobs','candidates','candidate_documents','processing_runs','ai_summaries','matches','notes','invitations','api_keys','webhooks'
  )
  loop
    -- Using dynamic SQL to attach triggers
    execute format('drop trigger if exists %I_audit on public.%I;', table_name || '_audit', table_name);
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function audit.log_event();', table_name || '_audit', table_name);
  end loop;
end$$;


