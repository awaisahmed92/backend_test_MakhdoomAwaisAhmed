-- Migration: Performance indexes

create index if not exists idx_org_members_org on public.organization_members(organization_id);
create index if not exists idx_org_members_user on public.organization_members(user_id);

create index if not exists idx_jobs_org on public.jobs(organization_id);
create index if not exists idx_jobs_status on public.jobs(status);

create index if not exists idx_candidates_org on public.candidates(organization_id);
create index if not exists idx_candidates_email on public.candidates(email);

create index if not exists idx_documents_candidate on public.candidate_documents(candidate_id);

create index if not exists idx_runs_org on public.processing_runs(organization_id);
create index if not exists idx_runs_job on public.processing_runs(job_id);
create index if not exists idx_runs_status on public.processing_runs(status);

create index if not exists idx_ai_summaries_org on public.ai_summaries(organization_id);
create index if not exists idx_ai_summaries_job on public.ai_summaries(job_id);
create index if not exists idx_ai_summaries_candidate on public.ai_summaries(candidate_id);

create index if not exists idx_matches_org on public.matches(organization_id);
create index if not exists idx_matches_job on public.matches(job_id);
create index if not exists idx_matches_candidate on public.matches(candidate_id);
create index if not exists idx_matches_score on public.matches(score desc);

create index if not exists idx_notes_org on public.notes(organization_id);
create index if not exists idx_notes_job on public.notes(job_id);
create index if not exists idx_notes_candidate on public.notes(candidate_id);

create index if not exists idx_invites_org on public.invitations(organization_id);
create index if not exists idx_invites_email on public.invitations(email);

create index if not exists idx_api_keys_org on public.api_keys(organization_id);

create index if not exists idx_webhooks_org on public.webhooks(organization_id);


