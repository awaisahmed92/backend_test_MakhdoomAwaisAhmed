-- Migration: Security helpers and RLS policies
-- Target: Supabase (Postgres 15+)

-- Safety: create schema comment
comment on schema public is 'Multi-tenant recruitment SaaS schema';

-- Helper: current_user_id()
create or replace function public.current_user_id()
returns uuid language sql stable as $$
  select auth.uid();
$$;

-- Helper: check if current user is a member of an organization
create or replace function public.is_org_member(org_id uuid)
returns boolean language sql stable as $$
  select exists (
    select 1 from public.organization_members m
    where m.organization_id = org_id
      and m.user_id = auth.uid()
  );
$$;

-- Helper: check if current user has any of the roles in an organization
create or replace function public.has_org_role(org_id uuid, roles public.user_role[])
returns boolean language sql stable as $$
  select exists (
    select 1 from public.organization_members m
    where m.organization_id = org_id
      and m.user_id = auth.uid()
      and m.role = any (roles)
  );
$$;

-- Trigger: ensure creator becomes owner member when creating an organization
create or replace function public.ensure_owner_membership()
returns trigger language plpgsql security definer as $$
begin
  if new.created_by is not null then
    insert into public.organization_members (organization_id, user_id, role, invited_by)
    values (new.id, new.created_by, 'owner', new.created_by)
    on conflict (organization_id, user_id) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists organizations_owner_membership on public.organizations;
create trigger organizations_owner_membership
after insert on public.organizations
for each row execute function public.ensure_owner_membership();

-- Enable RLS
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.profiles enable row level security;
alter table public.jobs enable row level security;
alter table public.candidates enable row level security;
alter table public.candidate_documents enable row level security;
alter table public.processing_runs enable row level security;
alter table public.ai_summaries enable row level security;
alter table public.matches enable row level security;
alter table public.notes enable row level security;
alter table public.invitations enable row level security;
alter table public.api_keys enable row level security;
alter table public.webhooks enable row level security;

-- Policies

-- organizations: members can view; creators can insert; owners/admins can update; owners can delete
create policy organizations_select on public.organizations
  for select using (public.is_org_member(id));

create policy organizations_insert on public.organizations
  for insert with check (true); -- allow any authenticated user via Supabase to create org; RLS will not block service role

create policy organizations_update on public.organizations
  for update using (public.has_org_role(id, array['owner','admin']))
  with check (public.has_org_role(id, array['owner','admin']));

create policy organizations_delete on public.organizations
  for delete using (public.has_org_role(id, array['owner']));

-- organization_members: only visible to members of the org
create policy organization_members_select on public.organization_members
  for select using (public.is_org_member(organization_id));

-- Only owners/admins can manage membership
create policy organization_members_insert on public.organization_members
  for insert with check (public.has_org_role(organization_id, array['owner','admin']));

create policy organization_members_update on public.organization_members
  for update using (public.has_org_role(organization_id, array['owner','admin']))
  with check (public.has_org_role(organization_id, array['owner','admin']));

create policy organization_members_delete on public.organization_members
  for delete using (public.has_org_role(organization_id, array['owner','admin']));

-- profiles: user can view/update self; org members may read basic info for members in same org
create policy profiles_select_self on public.profiles
  for select using (user_id = auth.uid() or exists (
    select 1 from public.organization_members m1
    join public.organization_members m2 on m1.organization_id = m2.organization_id
    where m1.user_id = auth.uid() and m2.user_id = user_id
  ));

create policy profiles_update_self on public.profiles
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());

-- jobs: org members can select; recruiters+ can insert/update/delete within org
create policy jobs_select on public.jobs
  for select using (public.is_org_member(organization_id));

create policy jobs_insert on public.jobs
  for insert with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy jobs_update on public.jobs
  for update using (public.has_org_role(organization_id, array['owner','admin','recruiter']))
  with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy jobs_delete on public.jobs
  for delete using (public.has_org_role(organization_id, array['owner','admin']));

-- candidates: org members can select; recruiters+ can manage
create policy candidates_select on public.candidates
  for select using (public.is_org_member(organization_id));

create policy candidates_insert on public.candidates
  for insert with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy candidates_update on public.candidates
  for update using (public.has_org_role(organization_id, array['owner','admin','recruiter']))
  with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy candidates_delete on public.candidates
  for delete using (public.has_org_role(organization_id, array['owner','admin']));

-- candidate_documents: derive org via candidate join
create policy candidate_documents_select on public.candidate_documents
  for select using (exists (
    select 1 from public.candidates c
    where c.id = candidate_id and public.is_org_member(c.organization_id)
  ));

create policy candidate_documents_insert on public.candidate_documents
  for insert with check (exists (
    select 1 from public.candidates c
    where c.id = candidate_id and public.has_org_role(c.organization_id, array['owner','admin','recruiter'])
  ));

create policy candidate_documents_delete on public.candidate_documents
  for delete using (exists (
    select 1 from public.candidates c
    where c.id = candidate_id and public.has_org_role(c.organization_id, array['owner','admin'])
  ));

-- processing_runs: org scoped
create policy processing_runs_select on public.processing_runs
  for select using (public.is_org_member(organization_id));

create policy processing_runs_insert on public.processing_runs
  for insert with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy processing_runs_update on public.processing_runs
  for update using (public.has_org_role(organization_id, array['owner','admin']))
  with check (public.has_org_role(organization_id, array['owner','admin']));

-- ai_summaries: org scoped
create policy ai_summaries_select on public.ai_summaries
  for select using (public.is_org_member(organization_id));

create policy ai_summaries_upsert on public.ai_summaries
  for insert with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy ai_summaries_update on public.ai_summaries
  for update using (public.has_org_role(organization_id, array['owner','admin','recruiter']))
  with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

-- matches: org scoped
create policy matches_select on public.matches
  for select using (public.is_org_member(organization_id));

create policy matches_upsert on public.matches
  for insert with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

create policy matches_update on public.matches
  for update using (public.has_org_role(organization_id, array['owner','admin','recruiter']))
  with check (public.has_org_role(organization_id, array['owner','admin','recruiter']));

-- notes: org scoped
create policy notes_select on public.notes
  for select using (public.is_org_member(organization_id));

create policy notes_insert on public.notes
  for insert with check (public.has_org_role(organization_id, array['owner','admin','recruiter']) and created_by = auth.uid());

create policy notes_update_own on public.notes
  for update using (created_by = auth.uid() and public.is_org_member(organization_id))
  with check (created_by = auth.uid() and public.is_org_member(organization_id));

create policy notes_delete_own on public.notes
  for delete using (created_by = auth.uid() and public.is_org_member(organization_id));

-- invitations: owners/admins only
create policy invitations_select on public.invitations
  for select using (public.has_org_role(organization_id, array['owner','admin']));

create policy invitations_manage on public.invitations
  for all using (public.has_org_role(organization_id, array['owner','admin']))
  with check (public.has_org_role(organization_id, array['owner','admin']));

-- api_keys: owners/admins only
create policy api_keys_select on public.api_keys
  for select using (public.has_org_role(organization_id, array['owner','admin']));

create policy api_keys_manage on public.api_keys
  for all using (public.has_org_role(organization_id, array['owner','admin']))
  with check (public.has_org_role(organization_id, array['owner','admin']));

-- webhooks: owners/admins only
create policy webhooks_select on public.webhooks
  for select using (public.has_org_role(organization_id, array['owner','admin']));

create policy webhooks_manage on public.webhooks
  for all using (public.has_org_role(organization_id, array['owner','admin']))
  with check (public.has_org_role(organization_id, array['owner','admin']));


