-- Migration: RPC functions exposed via Supabase

-- RPC: api_get_job_results(job_id uuid)
-- Uses auth context to infer orgs visible to caller and returns ranked results
create or replace function public.api_get_job_results(p_job_id uuid)
returns setof public.v_ranked_matches language sql stable as $$
  select * from public.v_ranked_matches v
  where v.job_id = p_job_id
  order by v.score desc, v.candidate_name asc;
$$;

-- RPC: api_queue_processing_run(org_id uuid, job_id uuid)
-- Creates a processing_run row; actual processing is done by backend worker listening to db changes or webhooks
create or replace function public.api_queue_processing_run(p_org_id uuid, p_job_id uuid)
returns uuid language plpgsql security definer as $$
declare
  new_id uuid := gen_random_uuid();
begin
  if not public.has_org_role(p_org_id, array['owner','admin','recruiter']) then
    raise exception 'insufficient_privilege';
  end if;

  insert into public.processing_runs (id, organization_id, job_id, status, created_by, started_at)
  values (new_id, p_org_id, p_job_id, 'queued', auth.uid(), now());
  return new_id;
end;
$$;


