-- Migration: Supabase Storage policies for candidate documents

-- Buckets are created via Supabase storage API; here we set policies via SQL
-- Assume bucket name: 'candidate-cvs'

-- Storage RLS uses storage.objects table
-- Ensure bucket exists (no-op if it does not; manage via dashboard ideally)

-- Policy: allow org members to read objects whose path starts with org/<org_id>/...
create policy if not exists "org members can read candidate cvs" on storage.objects
  for select using (
    bucket_id = 'candidate-cvs' and
    exists (
      select 1 from public.candidates c
      join public.candidate_documents d on d.candidate_id = c.id
      where d.storage_object_path = storage.objects.name
        and public.is_org_member(c.organization_id)
    )
  );

-- Policy: allow recruiters+ to upload to their org prefix
create policy if not exists "recruiters can upload candidate cvs" on storage.objects
  for insert with check (
    bucket_id = 'candidate-cvs' and
    exists (
      select 1 from public.candidates c
      join public.candidate_documents d on d.candidate_id = c.id
      where d.storage_object_path = storage.objects.name
        and public.has_org_role(c.organization_id, array['owner','admin','recruiter'])
    )
  );


