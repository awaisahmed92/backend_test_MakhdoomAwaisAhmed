-- Migration: Soft-delete support and RLS enforcement

-- 1) Add deleted_at to domain tables
alter table public.jobs add column if not exists deleted_at timestamptz;
alter table public.candidates add column if not exists deleted_at timestamptz;
alter table public.candidate_documents add column if not exists deleted_at timestamptz;
alter table public.processing_runs add column if not exists deleted_at timestamptz;
alter table public.ai_summaries add column if not exists deleted_at timestamptz;
alter table public.matches add column if not exists deleted_at timestamptz;
alter table public.notes add column if not exists deleted_at timestamptz;

-- 2) Soft delete trigger function (generic by id)
create or replace function public.soft_delete()
returns trigger language plpgsql as $$
begin
  execute format('update %I set deleted_at = now() where id = $1', TG_TABLE_NAME)
  using OLD.id;
  return null; -- skip real delete
end;
$$;

-- 3) Attach BEFORE DELETE triggers
drop trigger if exists jobs_soft_delete on public.jobs;
create trigger jobs_soft_delete before delete on public.jobs for each row execute function public.soft_delete();

drop trigger if exists candidates_soft_delete on public.candidates;
create trigger candidates_soft_delete before delete on public.candidates for each row execute function public.soft_delete();

drop trigger if exists candidate_documents_soft_delete on public.candidate_documents;
create trigger candidate_documents_soft_delete before delete on public.candidate_documents for each row execute function public.soft_delete();

drop trigger if exists processing_runs_soft_delete on public.processing_runs;
create trigger processing_runs_soft_delete before delete on public.processing_runs for each row execute function public.soft_delete();

drop trigger if exists ai_summaries_soft_delete on public.ai_summaries;
create trigger ai_summaries_soft_delete before delete on public.ai_summaries for each row execute function public.soft_delete();

drop trigger if exists matches_soft_delete on public.matches;
create trigger matches_soft_delete before delete on public.matches for each row execute function public.soft_delete();

drop trigger if exists notes_soft_delete on public.notes;
create trigger notes_soft_delete before delete on public.notes for each row execute function public.soft_delete();

-- 4) Recreate SELECT policies to hide soft-deleted rows

-- jobs
drop policy if exists jobs_select on public.jobs;
create policy jobs_select on public.jobs
  for select using (public.is_org_member(organization_id) and deleted_at is null);

-- candidates
drop policy if exists candidates_select on public.candidates;
create policy candidates_select on public.candidates
  for select using (public.is_org_member(organization_id) and deleted_at is null);

-- candidate_documents
drop policy if exists candidate_documents_select on public.candidate_documents;
create policy candidate_documents_select on public.candidate_documents
  for select using (deleted_at is null and exists (
    select 1 from public.candidates c
    where c.id = candidate_id and public.is_org_member(c.organization_id)
  ));

-- processing_runs
drop policy if exists processing_runs_select on public.processing_runs;
create policy processing_runs_select on public.processing_runs
  for select using (public.is_org_member(organization_id) and deleted_at is null);

-- ai_summaries
drop policy if exists ai_summaries_select on public.ai_summaries;
create policy ai_summaries_select on public.ai_summaries
  for select using (public.is_org_member(organization_id) and deleted_at is null);

-- matches
drop policy if exists matches_select on public.matches;
create policy matches_select on public.matches
  for select using (public.is_org_member(organization_id) and deleted_at is null);

-- notes
drop policy if exists notes_select on public.notes;
create policy notes_select on public.notes
  for select using (public.is_org_member(organization_id) and deleted_at is null);


