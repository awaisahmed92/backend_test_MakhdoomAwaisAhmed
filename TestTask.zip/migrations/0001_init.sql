-- Migration: Initial schema for multi-tenant recruitment SaaS
-- Target: Supabase (Postgres 15+)

-- 1) Types
create type public.user_role as enum ('owner', 'admin', 'recruiter', 'viewer');

-- 2) Organizations (tenants)
create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

-- 3) Organization members
create table if not exists public.organization_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.user_role not null default 'recruiter',
  invited_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

-- 4) Profiles (mirror of auth.users for convenience/metadata)
create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 5) Jobs (per organization)
create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  description text,
  location text,
  status text not null default 'open', -- open | closed | archived
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 6) Candidates (per organization)
create table if not exists public.candidates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  full_name text not null,
  email text,
  phone text,
  location text,
  years_experience numeric,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

-- 7) Candidate documents (CVs / resumes)
create table if not exists public.candidate_documents (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid not null references public.candidates(id) on delete cascade,
  storage_object_path text not null, -- path in Supabase Storage
  mime_type text,
  original_filename text,
  size_bytes bigint,
  uploaded_by uuid references auth.users(id),
  uploaded_at timestamptz not null default now()
);

-- 8) Processing runs (AI processing pipelines per job upload)
create table if not exists public.processing_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete set null,
  status text not null default 'queued', -- queued | running | completed | failed
  started_at timestamptz,
  completed_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  error_message text
);

-- 9) AI summaries per candidate per job
create table if not exists public.ai_summaries (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  candidate_id uuid not null references public.candidates(id) on delete cascade,
  summary text, -- AI generated recommendation summary
  json_payload jsonb, -- raw model output for traceability
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  unique (job_id, candidate_id)
);

-- 10) Matches (scored relationship of candidate to job)
create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  candidate_id uuid not null references public.candidates(id) on delete cascade,
  score numeric not null check (score >= 0 and score <= 100),
  reasons text, -- optional textual reasons or features
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  unique (job_id, candidate_id)
);

-- 11) Recruiter notes on candidates for a job
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete cascade,
  candidate_id uuid references public.candidates(id) on delete cascade,
  body text not null,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 12) Invitations (for SaaS org onboarding)
create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  email text not null,
  role public.user_role not null default 'recruiter',
  token text not null unique,
  invited_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  accepted_at timestamptz,
  revoked_at timestamptz,
  unique (organization_id, email) 
);

-- 13) API keys (per organization) for integrations
create table if not exists public.api_keys (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  hashed_key text not null, -- store only hashed
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  last_used_at timestamptz,
  unique (organization_id, name)
);

-- 14) Webhooks (per organization)
create table if not exists public.webhooks (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  url text not null,
  secret text, -- optional signing secret
  event text not null, -- e.g., match.created
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

-- 15) Common updated_at trigger
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
begin
  if exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'jobs' and column_name = 'updated_at') then
    create trigger jobs_set_updated_at before update on public.jobs for each row execute function public.set_updated_at();
  end if;
  if exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'profiles' and column_name = 'updated_at') then
    create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
  end if;
  if exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'notes' and column_name = 'updated_at') then
    create trigger notes_set_updated_at before update on public.notes for each row execute function public.set_updated_at();
  end if;
end$$;

-- 16) Useful constraints
alter table public.organizations add constraint organizations_slug_chk check (slug ~ '^[a-z0-9-]+$');


