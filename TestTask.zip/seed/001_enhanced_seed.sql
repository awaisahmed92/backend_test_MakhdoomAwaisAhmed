-- Enhanced seed: additional candidates, jobs, soft-deletes, and demo results

-- Another job
insert into public.jobs (id, organization_id, title, description, location, status, created_by)
values ('10000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000001', 'Data Scientist', 'ML pipelines and model ops', 'Remote', 'open', auth.uid())
on conflict (id) do nothing;

-- More candidates
insert into public.candidates (id, organization_id, full_name, email, phone, location, years_experience, created_by)
values
  ('20000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000001', 'Priya Nair', 'priya@example.com', '+1-555-0103', 'Remote', 5, auth.uid()),
  ('20000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000001', 'Carlos Ruiz', 'carlos@example.com', '+1-555-0104', 'Austin', 7, auth.uid()),
  ('20000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000001', 'Mina Lee', 'mina@example.com', '+1-555-0105', 'NYC', 3, auth.uid())
on conflict (id) do nothing;

-- Demo matches and summaries
select public.upsert_match_and_summary('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000004', 88, 'Solid DS background with Python/SQL.');
select public.upsert_match_and_summary('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000005', 81, 'Good MLOps exposure.');
select public.upsert_match_and_summary('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000006', 72, 'Junior but promising.');

-- Soft delete example: archive one candidate
update public.candidates set deleted_at = now() where id = '20000000-0000-0000-0000-000000000006';


