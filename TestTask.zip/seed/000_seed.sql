-- Seed: Sample data for multi-tenant recruitment SaaS
-- Note: In Supabase SQL editor, use service role or run as superuser for inserts into auth schema if needed.

-- Example org
insert into public.organizations (id, name, slug, created_by)
values ('00000000-0000-0000-0000-000000000001', 'Acme Recruiting', 'acme', auth.uid())
on conflict (id) do nothing;

-- Example users are managed by Supabase auth; ensure profiles exist when users sign in
-- Example members (assumes current auth.uid() is owner for demo)
insert into public.organization_members (organization_id, user_id, role)
values ('00000000-0000-0000-0000-000000000001', auth.uid(), 'owner')
on conflict (organization_id, user_id) do nothing;

-- Jobs
insert into public.jobs (id, organization_id, title, description, location, status, created_by)
values
  ('10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'Senior Backend Engineer', 'Build scalable APIs in Go/Node', 'Remote', 'open', auth.uid()),
  ('10000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'Product Manager', 'Own product lifecycle', 'NYC', 'open', auth.uid())
on conflict (id) do nothing;

-- Candidates
insert into public.candidates (id, organization_id, full_name, email, phone, location, years_experience, created_by)
values
  ('20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'Jane Doe', 'jane@example.com', '+1-555-0100', 'Remote', 6, auth.uid()),
  ('20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'John Smith', 'john@example.com', '+1-555-0101', 'NYC', 4, auth.uid()),
  ('20000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000001', 'Alex Kim', 'alex@example.com', '+1-555-0102', 'SF', 8, auth.uid())
on conflict (id) do nothing;

-- Matches
insert into public.matches (organization_id, job_id, candidate_id, score, reasons, created_by)
values
  ('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000001', 92, 'Strong backend experience; Go/Node match', auth.uid()),
  ('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000002', 78, 'Some Node experience; needs Go ramp-up', auth.uid()),
  ('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000003', 85, 'Strong PM collaboration history', auth.uid());

-- AI summaries
insert into public.ai_summaries (organization_id, job_id, candidate_id, summary, json_payload, created_by)
values
  ('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000001', 'Highly suitable for backend role with cloud experience.', '{"model":"gpt","tokens":123}', auth.uid())
on conflict (job_id, candidate_id) do nothing;


